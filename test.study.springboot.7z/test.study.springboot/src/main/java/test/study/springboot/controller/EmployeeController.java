package test.study.springboot.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import test.study.springboot.model.Employee;
import test.study.springboot.service.EmployeeService;

import java.util.List;

@RestController
//@RequestMapping("/v1")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping("/employee")
    public String save(@RequestBody Employee employee) {
        boolean flag = employeeService.save(employee);
        if (flag) return "Employee Details save successfully";
        else {
            return "Failure - Not Success";
        }
    }

    @GetMapping("/employee/{id}")
    public List<Employee> fetchDetails(@PathVariable("id") String id) {
        return employeeService.getEmpDetails(Integer.parseInt(id));
    }
}
