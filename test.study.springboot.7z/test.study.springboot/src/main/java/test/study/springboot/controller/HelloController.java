package test.study.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import test.study.springboot.model.Employee;

@RestController
//@RequestMapping("/v1")
public class HelloController {

    @Autowired
    Employee employee;


    @GetMapping("/hello")
    public String index() {
        return "Greetings from Spring ";
    }

    @GetMapping("/")
    public String home() {
        return "Welcome user";
    }

    @GetMapping("/user")
    public String readValueFromUrl(@RequestParam("name") String name, @RequestParam("id") String id) {
        return "Welcome: " + name + "  :: Id::" + id;
    }

    @GetMapping("/test2/{name}")
    public String readValueFromUrl(@PathVariable("name") String name) {
        return "Welcome Path Variable: " + name;
    }

    @GetMapping("/test3")
    public Employee test3() {
        System.out.println("::::" + employee);
//        employee.setId(12);
//        employee.setName("Test");
//        employee.setMailId("test@test.com");

        throw new IndexOutOfBoundsException(" Index oot of bound:");
//        return employee;
    }


}
