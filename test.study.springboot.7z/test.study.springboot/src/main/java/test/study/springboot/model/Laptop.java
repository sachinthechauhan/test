package test.study.springboot.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Component
@Data
public class Laptop {
    private int id;
    private String model;
    private String companyName;
}
