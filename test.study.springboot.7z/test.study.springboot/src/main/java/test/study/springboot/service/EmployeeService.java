package test.study.springboot.service;

import test.study.springboot.model.Employee;

import java.util.List;

public interface EmployeeService {
    public boolean save(Employee emp);
    public List<Employee> getEmpDetails(int id);
}
