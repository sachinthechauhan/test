package test.study.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import test.study.springboot.dao.EmployeeRepository;
import test.study.springboot.model.Employee;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository repository;

    @Override
    public boolean save(Employee emp) {
        try {
            repository.save(emp);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    @Override
    public List<Employee> getEmpDetails(int id) {

        List<Employee> empList=repository.findAll();

//       return  (Employee)repository.getById(id);
        return  empList;
    }
}
